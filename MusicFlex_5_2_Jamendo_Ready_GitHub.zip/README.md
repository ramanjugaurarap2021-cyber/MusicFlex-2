# MusicFlex 5.2 — GitHub Android Project

Ready-to-build Android project for MusicFlex v5.2.

Included:
- Audius online search/streaming
- Jamendo integration with the supplied live Client ID
- Local music import + Android file picker
- Internet permission
- Notification permission
- Foreground media playback permissions/service
- MusicFlex launcher icon
- Web manifest + web icons inside Android assets
- GitHub Actions workflow for building the debug APK

## Jamendo
The supplied Jamendo application Client ID is already configured in:
`app/src/main/assets/MusicFlex.html`

The app uses HTTPS APIs for Audius, Jamendo and LRCLIB.

## Build on GitHub
1. Upload the contents of this folder to a GitHub repository.
2. Open **Actions**.
3. Run **Build MusicFlex APK** (or push to `main`/`master`).
4. Download the `MusicFlex-5.2-debug` artifact.
